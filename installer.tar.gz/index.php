<?php
define('ROOT_DIR', realpath(dirname(__FILE__)));

require ROOT_DIR.'/Autoloader.php';

